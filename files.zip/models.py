from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    is_logged_in = Column(Boolean, default=False)

    borrows = relationship("BorrowRecord", back_populates="user")


class Device(Base):
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    is_available = Column(Boolean, default=True)

    borrows = relationship("BorrowRecord", back_populates="device")


class BorrowRecord(Base):
    __tablename__ = "borrow_records"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    borrowed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    returned_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="borrows")
    device = relationship("Device", back_populates="borrows")
