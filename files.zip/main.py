from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timezone
from database import SessionLocal, engine
import models, schemas

# Create all tables on startup
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Device Borrowing System")


# --- DB Dependency ---

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# --- Root ---

@app.get("/")
def read_root():
    return {"message": "Device Borrowing System API"}


# -------------------------
# USER ENDPOINTS
# -------------------------

@app.post("/users", response_model=schemas.UserResponse, tags=["Users"])
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    """Create a new user."""
    existing = db.query(models.User).filter(models.User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    db_user = models.User(name=user.name, email=user.email)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users", response_model=list[schemas.UserResponse], tags=["Users"])
def get_all_users(db: Session = Depends(get_db)):
    """Get all users."""
    return db.query(models.User).all()

@app.get("/users/{user_id}", response_model=schemas.UserResponse, tags=["Users"])
def get_user(user_id: int, db: Session = Depends(get_db)):
    """Get a single user by their ID."""
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


# -------------------------
# AUTH ENDPOINTS
# -------------------------

@app.post("/login", response_model=schemas.UserResponse, tags=["Auth"])
def login(request: schemas.LoginRequest, db: Session = Depends(get_db)):
    """Log a user in by their user ID."""
    user = db.query(models.User).filter(models.User.id == request.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.is_logged_in:
        raise HTTPException(status_code=400, detail="User is already logged in")
    user.is_logged_in = True
    db.commit()
    db.refresh(user)
    return user

@app.post("/logout", response_model=schemas.UserResponse, tags=["Auth"])
def logout(request: schemas.LogoutRequest, db: Session = Depends(get_db)):
    """Log a user out by their user ID."""
    user = db.query(models.User).filter(models.User.id == request.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if not user.is_logged_in:
        raise HTTPException(status_code=400, detail="User is not currently logged in")
    user.is_logged_in = False
    db.commit()
    db.refresh(user)
    return user


# -------------------------
# DEVICE ENDPOINTS
# -------------------------

@app.post("/devices", response_model=schemas.DeviceResponse, tags=["Devices"])
def create_device(device: schemas.DeviceCreate, db: Session = Depends(get_db)):
    """Register a new device."""
    db_device = models.Device(name=device.name)
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    return db_device

@app.get("/devices", response_model=list[schemas.DeviceResponse], tags=["Devices"])
def get_all_devices(db: Session = Depends(get_db)):
    """Get all devices and their availability."""
    return db.query(models.Device).all()

@app.get("/devices/{device_id}", response_model=schemas.DeviceResponse, tags=["Devices"])
def get_device(device_id: int, db: Session = Depends(get_db)):
    """Get a single device by its ID."""
    device = db.query(models.Device).filter(models.Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return device


# -------------------------
# BORROW ENDPOINTS
# -------------------------

@app.post("/borrow", response_model=schemas.BorrowRecordResponse, tags=["Borrowing"])
def borrow_device(request: schemas.BorrowRequest, db: Session = Depends(get_db)):
    """Borrow a device. User must be logged in and the device must be available."""
    user = db.query(models.User).filter(models.User.id == request.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if not user.is_logged_in:
        raise HTTPException(status_code=403, detail="User must be logged in to borrow a device")

    device = db.query(models.Device).filter(models.Device.id == request.device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    if not device.is_available:
        raise HTTPException(status_code=400, detail="Device is not available")

    # Mark device as unavailable
    device.is_available = False

    # Create borrow record
    record = models.BorrowRecord(user_id=user.id, device_id=device.id)
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

@app.post("/return", response_model=schemas.BorrowRecordResponse, tags=["Borrowing"])
def return_device(request: schemas.ReturnRequest, db: Session = Depends(get_db)):
    """Return a borrowed device."""
    record = (
        db.query(models.BorrowRecord)
        .filter(
            models.BorrowRecord.user_id == request.user_id,
            models.BorrowRecord.device_id == request.device_id,
            models.BorrowRecord.returned_at == None,
        )
        .first()
    )
    if not record:
        raise HTTPException(status_code=404, detail="No active borrow record found for this user and device")

    record.returned_at = datetime.now(timezone.utc)

    device = db.query(models.Device).filter(models.Device.id == request.device_id).first()
    if device:
        device.is_available = True

    db.commit()
    db.refresh(record)
    return record

@app.get("/borrows", response_model=list[schemas.BorrowRecordResponse], tags=["Borrowing"])
def get_active_borrows(db: Session = Depends(get_db)):
    """Get all currently active (unreturned) borrow records."""
    return db.query(models.BorrowRecord).filter(models.BorrowRecord.returned_at == None).all()
