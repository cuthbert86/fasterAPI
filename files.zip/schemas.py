from pydantic import BaseModel
from datetime import datetime
from typing import Optional


# --- User Schemas ---

class UserCreate(BaseModel):
    name: str
    email: str

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    is_logged_in: bool

    class Config:
        from_attributes = True


# --- Device Schemas ---

class DeviceCreate(BaseModel):
    name: str

class DeviceResponse(BaseModel):
    id: int
    name: str
    is_available: bool

    class Config:
        from_attributes = True


# --- Auth Schemas ---

class LoginRequest(BaseModel):
    user_id: int

class LogoutRequest(BaseModel):
    user_id: int


# --- Borrow Schemas ---

class BorrowRequest(BaseModel):
    user_id: int
    device_id: int

class ReturnRequest(BaseModel):
    user_id: int
    device_id: int

class BorrowRecordResponse(BaseModel):
    id: int
    user_id: int
    device_id: int
    borrowed_at: datetime
    returned_at: Optional[datetime]

    class Config:
        from_attributes = True
